import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const PokeCard = (props) => {
    const{name, url} = props.poke;
    const [poke, setPoke] = useState({})
    const [typeArray, setTypeArray] = useState([])

    async function getPoke(){
        const response = await fetch(url)
        const data = await response.json()
        setPoke(data.sprites.front_default)
        
        
    }
{/* поменять имя poke*/}
    useEffect(() =>{
        console.log(props.poke, url)
        getPoke()
    }, [])

    return (
        <Link to={`/pokemon/${name}`}>
            <div>
            <img src={poke} />
            <h4>{name}</h4>
            </div>
        </Link>
    );
};

export default PokeCard;