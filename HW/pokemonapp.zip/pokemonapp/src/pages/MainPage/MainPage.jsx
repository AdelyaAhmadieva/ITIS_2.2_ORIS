import React, { useEffect, useState } from 'react';
import PokemonCard from './components/PokemonCard';
import './MainPage.css'

const MainPage = () => {

    const [poke, setPoke] = useState([])

    async function getPoke(){
        const responce = await fetch('https://pokeapi.co/api/v2/pokemon?limit=30')
        const data = await responce.json()
        setPoke(data.results)
    }

    useEffect(() =>{
        getPoke()
    }, [])

    return (
        <div className='pokemon-list'>
        {poke.map((pok)=>(
            pok.index === 0 ? (null) : <PokemonCard poke = {pok} />
        ))}
        </div>
    );
};

export default MainPage;

